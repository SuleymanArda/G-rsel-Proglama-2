using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("UI")]
    [SerializeField] private TMP_Text scoreText;   // Canvas -> ScoreText s�r�kle
    [SerializeField] private GameObject winPanel;  // Canvas -> WinPanel s�r�kle

    private int score;
    private int targetCount;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
    }

    private void Start()
    {
        // Sahnede toplanabilirlerin say�s�n� otomatik say
        targetCount = GameObject.FindGameObjectsWithTag("Pickup").Length;

        // Referanslar atanmam��sa otomatik dene (g�venlik a��)
        if (scoreText == null)
            scoreText = GameObject.Find("ScoreText")?.GetComponent<TMP_Text>();

        UpdateUI();
        if (winPanel != null) winPanel.SetActive(false);
    }

    public void AddScore(int add)
    {
        score += add;
        UpdateUI();

        if (score >= targetCount && targetCount > 0)
            Win();
    }

    private void UpdateUI()
    {
        if (scoreText != null)
            scoreText.text = $"{score}/{targetCount}";
    }

    private void Win()
    {
        if (winPanel != null) winPanel.SetActive(true);
        // �ste�e ba�l�:
        // Time.timeScale = 0f; // oyunu dondur
    }
}
