using UnityEngine;

public class PlayerCollector : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Pickup"))
        {
            GameManager.Instance?.AddScore(1);
            Destroy(other.gameObject);
        }
    }
}
