﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    private Rigidbody rb;
    private Vector3 input;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Yön tuşları veya WASD
        float h = Input.GetAxis("Horizontal"); // A/D veya ← →
        float v = Input.GetAxis("Vertical");   // W/S veya ↑ ↓

        input = new Vector3(h, 0, v);
    }

    void FixedUpdate()
    {
        // Fizik tabanlı hareket
        Vector3 move = input * moveSpeed;
        Vector3 newPosition = rb.position + move * Time.fixedDeltaTime;
        rb.MovePosition(newPosition);
    }
}
